const $ = require("jquery");

$("#target").html("hello friends!");