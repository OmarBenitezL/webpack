const $ = require("jquery");

$("#target").html("hello world!");